/* ============================================================
   Email Delivery Expert Guide — Shared Navigation JS
   ============================================================ */

/* ── Sidebar nav data ──────────────────────────────────────── */
const NAV = [
  {
    day: 1, label: "Email fundamentals", color: "#185FA5", hours: "4 hrs",
    topics: [
      { id: "d1-t1", file: "d1-t1-email-flow.html",          title: "End-to-end email flow",          time: "45 min", done: true  },
      { id: "d1-t2", file: "d1-t2-envelope-vs-message.html", title: "Envelope vs message headers",    time: "30 min", done: true  },
      { id: "d1-t3", file: "d1-t3-rfc-map.html",             title: "Key RFC map",                    time: "30 min", done: true  },
      { id: "d1-t4", file: "d1-t4-ports.html",               title: "Ports: 25, 465, 587, 2525",      time: "20 min", done: true },
      { id: "d1-t5", file: "d1-t5-message-structure.html",   title: "Message structure & MIME",       time: "45 min", done: true },
    ]
  },
  {
    day: 2, label: "SMTP protocol deep dive", color: "#0F6E56", hours: "5 hrs",
    topics: [
      { id: "d2-t1", file: "d2-t1-state-machine.html",    title: "The SMTP state machine",           time: "60 min", done: true },
      { id: "d2-t2", file: "d2-t2-response-codes.html",   title: "All SMTP response codes",          time: "45 min", done: true },
      { id: "d2-t3", file: "d2-t3-esmtp-extensions.html", title: "ESMTP extensions (EHLO)",          time: "45 min", done: true },
      { id: "d2-t4", file: "d2-t4-starttls.html",         title: "STARTTLS: upgrade & pitfalls",     time: "40 min", done: true },
      { id: "d2-t5", file: "d2-t5-auth-mechanisms.html",  title: "AUTH: PLAIN, LOGIN, XOAUTH2",      time: "30 min", done: true },
      { id: "d2-t6", file: "d2-t6-smtp-transcript.html",  title: "Reading a raw SMTP transcript",    time: "40 min", done: true },
    ]
  },
  {
    day: 3, label: "DNS for email", color: "#533AB7", hours: "4 hrs",
    topics: [
      { id: "d3-t1", file: "d3-t1-dns-fundamentals.html", title: "DNS fundamentals for email",      time: "45 min", done: true },
      { id: "d3-t2", file: "d3-t2-mx-records.html",       title: "MX records: lookup & fallback",   time: "40 min", done: true },
      { id: "d3-t3", file: "d3-t3-ptr-records.html",      title: "PTR records & reverse DNS",       time: "35 min", done: true },
      { id: "d3-t4", file: "d3-t4-txt-records.html",      title: "TXT records: SPF, DKIM, DMARC",   time: "40 min", done: true },
      { id: "d3-t5", file: "d3-t5-dig-tool.html",         title: "Using dig as an email expert",    time: "40 min", done: true },
      { id: "d3-t6", file: "d3-t6-dnsbl.html",            title: "DNSBLs & reputation lookups",     time: "30 min", done: true },
    ]
  },
  {
    day: 4, label: "SPF, DKIM, DMARC, ARC", color: "#BA7517", hours: "5 hrs",
    topics: [
      { id: "d4-t1", file: "d4-t1-spf.html",           title: "SPF: how it works & breaks",         time: "60 min", done: true },
      { id: "d4-t2", file: "d4-t2-dkim.html",          title: "DKIM: signing & key rotation",       time: "70 min", done: true },
      { id: "d4-t3", file: "d4-t3-dmarc.html",         title: "DMARC: policy & reporting",          time: "60 min", done: true },
      { id: "d4-t4", file: "d4-t4-arc.html",           title: "ARC: authenticated received chain",  time: "40 min", done: true },
      { id: "d4-t5", file: "d4-t5-auth-header.html",   title: "Walk through a real auth header",    time: "45 min", done: true },
      { id: "d4-t6", file: "d4-t6-bimi.html",          title: "BIMI and VMC: brand indicators",     time: "20 min", done: true },
    ]
  },
  {
    day: 5, label: "Bounces, DSN & delivery status", color: "#A32D2D", hours: "4 hrs",
    topics: [
      { id: "d5-t1", file: "d5-t1-hard-soft-bounce.html", title: "Hard vs soft bounce",             time: "40 min", done: true },
      { id: "d5-t2", file: "d5-t2-dsn-format.html",       title: "DSN format: RFC 3464 anatomy",    time: "50 min", done: true },
      { id: "d5-t3", file: "d5-t3-enhanced-codes.html",   title: "X.Y.Z enhanced status codes",     time: "40 min", done: true },
      { id: "d5-t4", file: "d5-t4-fbl-arf.html",          title: "FBL: feedback loops & ARF",       time: "40 min", done: true },
      { id: "d5-t5", file: "d5-t5-bounce-parsing.html",   title: "Bounce email parsing in practice",time: "45 min", done: true },
    ]
  },
  {
    day: 6, label: "Deliverability & reputation", color: "#3B6D11", hours: "4 hrs",
    topics: [
      { id: "d6-t1", file: "d6-t1-ip-reputation.html",  title: "IP reputation: how ISPs score",    time: "50 min", done: true },
      { id: "d6-t2", file: "d6-t2-ip-warmup.html",      title: "IP warm-up: strategy & execution", time: "40 min", done: true },
      { id: "d6-t3", file: "d6-t3-isp-behaviour.html",  title: "ISP behaviour: Gmail, Outlook, Yahoo", time: "45 min", done: true },
      { id: "d6-t4", file: "d6-t4-list-hygiene.html",   title: "List hygiene & engagement",        time: "35 min", done: true },
      { id: "d6-t5", file: "d6-t5-blacklists.html",     title: "Blacklists: detect, impact, delist",time: "35 min", done: true },
    ]
  },
  {
    day: 7, label: "Debugging like an expert", color: "#5F5E5A", hours: "4 hrs",
    topics: [
      { id: "d7-t1", file: "d7-t1-header-reading.html",  title: "Reading a full email header",      time: "50 min", done: true },
      { id: "d7-t2", file: "d7-t2-diagnostic-checklist.html", title: "Diagnostic checklist",        time: "40 min", done: true },
      { id: "d7-t3", file: "d7-t3-toolbox.html",         title: "Toolbox: dig, swaks, MXToolbox",   time: "40 min", done: true },
      { id: "d7-t4", file: "d7-t4-failure-patterns.html",title: "Common failure patterns",          time: "45 min", done: true },
      { id: "d7-t5", file: "d7-t5-bulk-sender-2024.html",title: "Gmail Feb 2024 bulk sender rules", time: "25 min", done: true },
    ]
  },
];

/* Flat topic list for prev/next navigation */
const FLAT_TOPICS = [];
NAV.forEach(day => day.topics.forEach(t => FLAT_TOPICS.push({ ...t, dayLabel: day.label, dayColor: day.color })));

/* ── Build sidebar ─────────────────────────────────────────── */
function buildSidebar(currentFile) {
  const sidebar = document.getElementById('sidebar');
  if (!sidebar) return;

  let html = `
    <div class="sidebar-brand">
      <a href="index.html">Email Delivery Guide</a>
      <div class="brand-sub">7-day expert curriculum</div>
    </div>`;

  NAV.forEach(day => {
    html += `<div class="sidebar-day">
      <div class="sidebar-day-label">
        <span class="day-dot" style="background:${day.color}"></span>
        Day ${day.day} &mdash; ${day.label}
      </div>`;
    day.topics.forEach(t => {
      const isActive = currentFile && currentFile.endsWith(t.file);
      const cls = isActive ? 'active' : (t.done ? 'done' : 'stub');
      const statusHtml = t.done
        ? '<span class="topic-status status-done">done</span>'
        : '<span class="topic-status status-stub">soon</span>';
      const href = t.done ? t.file : '#';
      html += `<a href="${href}" class="sidebar-topic ${cls}">
        ${t.title}${statusHtml}
      </a>`;
    });
    html += `</div>`;
  });

  sidebar.innerHTML = html;
}

/* ── Topbar nav ────────────────────────────────────────────── */
function buildTopbar(currentFile) {
  const topbar = document.getElementById('topbar');
  if (!topbar) return;

  const idx = FLAT_TOPICS.findIndex(t => currentFile && currentFile.endsWith(t.file));
  if (idx === -1) return;

  const cur = FLAT_TOPICS[idx];
  const prev = FLAT_TOPICS[idx - 1];
  const next = FLAT_TOPICS[idx + 1];

  topbar.innerHTML = `
    <span class="topbar-day-badge" style="background:${cur.dayColor}22;color:${cur.dayColor}">
      ${cur.dayLabel}
    </span>
    <span class="topbar-title">${cur.title}</span>
    <div class="topbar-nav">
      ${prev && prev.done ? `<a href="${prev.file}" class="topbar-btn">&larr; Prev</a>` : ''}
      <a href="index.html" class="topbar-btn">Home</a>
      ${next && next.done ? `<a href="${next.file}" class="topbar-btn">Next &rarr;</a>` : ''}
    </div>`;
}

/* ── Page nav (bottom prev/next) ───────────────────────────── */
function buildPageNav(currentFile) {
  const el = document.getElementById('page-nav');
  if (!el) return;

  const idx = FLAT_TOPICS.findIndex(t => currentFile && currentFile.endsWith(t.file));
  if (idx === -1) return;

  const prev = FLAT_TOPICS[idx - 1];
  const next = FLAT_TOPICS[idx + 1];

  el.innerHTML = `
    <div>
      ${prev && prev.done ? `<a href="${prev.file}" class="page-nav-btn">
        <div class="page-nav-dir">&larr; Previous</div>
        <div class="page-nav-name">${prev.title}</div>
      </a>` : ''}
    </div>
    <div>
      ${next ? `<a href="${next.file}" class="page-nav-btn next ${next.done ? '' : 'stub'}">
        <div class="page-nav-dir">Next &rarr;</div>
        <div class="page-nav-name">${next.title}</div>
      </a>` : ''}
    </div>`;
}

/* ── Copy utility ──────────────────────────────────────────── */
function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(showToast).catch(() => fallbackCopy(text));
  } else { fallbackCopy(text); }
}
function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;opacity:0';
  document.body.appendChild(ta); ta.focus(); ta.select();
  try { document.execCommand('copy'); showToast(); } catch(e) {}
  document.body.removeChild(ta);
}
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg || 'Copied to clipboard';
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

function copyCliff(id) {
  const el = document.getElementById(id);
  if (el) copyText(el.innerText);
}

/* ── Init ──────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  const file = window.location.pathname.split('/').pop() || 'index.html';
  buildSidebar(file);
  buildTopbar(file);
  buildPageNav(file);
});
